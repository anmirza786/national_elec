from django.db import models
# from product.
# # Create your models here.
# class CartPaid(models.Model):
#     product = 